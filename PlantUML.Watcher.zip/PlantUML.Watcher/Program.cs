﻿namespace PlantUML.Watcher
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var app = new UMLWatcherApp();

            app.Run(args);
        }
    }
}
